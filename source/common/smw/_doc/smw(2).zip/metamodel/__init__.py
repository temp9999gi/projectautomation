"""The metamodel package contains metamodels for different modeling lanugages and the MetaMM module."""
