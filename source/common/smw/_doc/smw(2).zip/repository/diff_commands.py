delete_command = "del"
insert_command = "ins"
change_one_association = "change_association"
change_xmiid_command = "change_xmiid"
change_type_command = "change_type"
change_attribute_command = "change_attribute"

