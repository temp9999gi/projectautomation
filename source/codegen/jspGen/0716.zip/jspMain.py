# -*- coding: utf-8 -*-
from xml.dom.minidom import *
import sys
from subprocess import *
from CommonUtil import *
from classDef import *

def parseXml(aClassInfo, inXmlFile):
    xmlFile = inXmlFile

    doc = getDomEncodeUtf8(xmlFile)
    
    className         = doc.getElementsByTagName("classInfo")[0].getAttribute('className')
    packagePath       = doc.getElementsByTagName("classInfo")[0].getAttribute('packagePath')

    aClassInfo = ClassInfo()
    aClassInfo.setAttributes(className,packagePath)

    aClassInfo.setAttributesOfPropertyInfo(doc,aClassInfo)

    return aClassInfo

def Run():

    aClassInfo = ClassInfo()

    inXmlFile = './input/'+sys.argv[1]

    aClassInfo = parseXml(aClassInfo, inXmlFile)


    templateName = JSP_TEMPLATE
    fileName = OUT_DIR + aClassInfo.className + '.jsp'

    aTemplate = generateCode(aClassInfo, templateName)

    writeFile(fileName, aTemplate)

    # call('python C:\_tools\Python24\Scripts\cog.py -r ./output/Account.java')

    print 'The End:'

if __name__ == "__main__":

    #if len(sys.argv) < 2:
    #    print "USAGE: python genMain.py Class.xml"
    #    sys.exit()

    Run()