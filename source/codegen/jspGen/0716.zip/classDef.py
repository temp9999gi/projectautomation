from CommonUtil import *

class ClassInfo :
    def __init__(self):
        self.className = ''
        self.packagePath = ''
        self.propertyInfoList = []
        self.trTdByLine = []
        
        
    def addPropertyInfoList(self, aPropertyInfo):
        self.propertyInfoList.append(aPropertyInfo)

    def setAttributes(self,className,packagePath):
        self.className = className
        self.packagePath = packagePath
        
    def setAttributesOfPropertyInfo(self, doc, aClassInfo):
        myAttributeList = doc.getElementsByTagName('property')
    
        for myAttribute in myAttributeList:
            propertyName   = myAttribute.getAttribute('name')
            propertyType   = myAttribute.getAttribute('type')
            line   = myAttribute.getAttribute('line')
    
            aPropertyInfo = PropertyInfo(propertyName, propertyType)
            aPropertyInfo.setLine(line)
            
            aClassInfo.addPropertyInfoList(aPropertyInfo)
                
        self.setTrTdByLine()
        return aClassInfo

    def setTrTdByLine(self):
        line = 0

        oldLine='0'
        for p in self.propertyInfoList:
            
            if oldLine == '0' :
                self.trTdByLine.append('              <tr>\n' + p.trTdString)
                oldLine = p.line 
            else: 
                if p.line == oldLine:
                    self.trTdByLine.append(p.trTdString)
                else:
                
                    ss = '              </tr>\n\n              <tr>\n' + p.trTdString
                    self.trTdByLine.append(ss)
                
                oldLine = p.line
        
        self.trTdByLine.append('              </tr>')
        
                
#               oldLine = p.line 
#               
#           i  = i + 1
#           if p.trTdString
#           print p.trTdString
        


class PropertyInfo :
    def __init__(self, propertyName, propertyType):
        self.propertyName = propertyName
        self.propertyType = propertyType
        # self.capPropertyName = capitalize1(propertyName)
        
        self.trTdString=''
        self.line=''
        
        self.setTrTdString()
                
    def setTrTdString(self):
        templateName = TR_TD_TEMPLATE           
        ss = {'propertyName' : self.propertyName, 'propertyType' : self.propertyType}
        aTemplate = generateCode(ss, templateName)
        self.trTdString = str(aTemplate)
        
        #print trTdString
        
#				ss = SPC4 + '%(lowerClassName)s.set%(cap1WhereArg)s(%(whereArg)s);' % \
#				      {'lowerClassName': lowerClassName, 'cap1WhereArg': cap1WhereArg, \
#				       'whereArg': whereArg}        
#        
        
    def setLine(self, line):
        self.line = line