from CommonUtil import *
import string

class MasterInfo :
    def __init__(self):
        self.fileName = ''
        self.title = ''
        self.tableTitle = ''
        self.titleMgr =''
        self.titleScreen =''
        
        self.propertyInfoList = []
        self.trTdByLine = []


    def addPropertyInfoList(self, aPropertyInfo):
        self.propertyInfoList.append(aPropertyInfo)

    def setAttributes(self,fileName, title, tableTitle):
        self.fileName = fileName
        self.title = title
        self.tableTitle = tableTitle        
        self.setTitle(title)

    def setTitle(self, title):
        (self.titleMgr,self.titleScreen) = string.split(title,'-')


    def setAttributesOfPropertyInfo(self, doc, aMasterInfo):
        myAttributeList = doc.getElementsByTagName('property')

        for myAttribute in myAttributeList:
            propertyName   = myAttribute.getAttribute('name')
            propertyType   = myAttribute.getAttribute('type')
            line           = myAttribute.getAttribute('line')

            aPropertyInfo = PropertyInfo(propertyName, propertyType)
            aPropertyInfo.setLine(line)

            aMasterInfo.addPropertyInfoList(aPropertyInfo)

        self.setTrTdByLine()
        return aMasterInfo

    def setTrTdByLine(self):
        i = 0
        for p in self.propertyInfoList:
            if i == 0 :
                (n1, t1) = (p.propertyName, p.propertyType)
                i = i +1
                if len(self.propertyInfoList) == (self.propertyInfoList.index(p)+1):
                    self.getTr2(n1, t1, n2, t2)
            elif i == 1 :
                (n2, t2) = (p.propertyName, p.propertyType)
                i = 0
                self.getTr1(n1, t1, n2, t2)

        
        
        
    def setTrTdByLine111111(self):
        i = 0
        for p in self.propertyInfoList:
            if i == 0 :
                (n1, t1) = (p.propertyName, p.propertyType)
                i = i +1
                if len(self.propertyInfoList) == (self.propertyInfoList.index(p)+1):
                    self.getTr2(n1, t1, n2, t2)
            elif i == 1 :
                (n2, t2) = (p.propertyName, p.propertyType)
                i = 0
                self.getTr1(n1, t1, n2, t2)

    def getTr1(self,n1, t1, n2, t2):
        templateName = TR_TD_TEMPLATE
        ss = {'propertyName1' : n1, 'propertyType1' : t1, 'propertyName2' : n2, 'propertyType2' : t2}
        aTemplate = generateCode(ss, templateName)
        trTdString = str(aTemplate)
        self.trTdByLine.append(trTdString)


    def getTr2(self,n1, t1, n2, t2):
        templateName = TR_TD_1LINE_TEMPLATE
        ss = {'propertyName1' : n1, 'propertyType1' : t1}
        aTemplate = generateCode(ss, templateName)
        trTdString = str(aTemplate)
        self.trTdByLine.append(trTdString)




class PropertyInfo :
    def __init__(self, propertyName, propertyType):
        self.propertyName = propertyName
        self.propertyType = propertyType
        # self.capPropertyName = capitalize1(propertyName)

        self.trTdString=''
        self.line=''

        self.setTrTdString()

    def setTrTdString(self):
        pass

    def setTrTdString1(self):
        templateName = TR_TD_TEMPLATE
        ss = {'propertyName' : self.propertyName, 'propertyType' : self.propertyType}
        aTemplate = generateCode(ss, templateName)
        self.trTdString = str(aTemplate)

        #print trTdString

#				ss = SPC4 + '%(lowerfileName)s.set%(cap1WhereArg)s(%(whereArg)s);' % \
#				      {'lowerfileName': lowerfileName, 'cap1WhereArg': cap1WhereArg, \
#				       'whereArg': whereArg}
#

    def setLine(self, line):
        self.line = line