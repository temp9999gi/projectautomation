﻿# -*- coding: utf-8 -*-
# start
# from CommonUtil import *
from MetaInfo import *

class ClassOperation(MetaInfo):
	def __init__(self):	
		MetaInfo.__init__		


