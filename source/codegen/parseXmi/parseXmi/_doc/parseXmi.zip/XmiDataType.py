from MetaInfo import *

class XmiDataType(MetaInfo):
	def __init__(self):
		MetaInfo.__init__
