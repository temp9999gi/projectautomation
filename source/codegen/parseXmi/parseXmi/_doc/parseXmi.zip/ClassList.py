﻿# -*- coding: utf-8 -*-
# import sys
# from Constants import *
# start
# import handyxml

import logging

log = logging.getLogger('ClassList')

class ClassList:
	global XMI
	def __init__(self):	
		#self.classDictByName = {}
		self.classDictXmiId = {}
		self.taggedValueDictByModelElementXmiId = {}
		self.classInfoList = []		
		self.classAttributeList = []
		self.classOperationList = []
		self.taggedValueList = []		
		self.dataTypeList = []
		self.dataTypeDict = {}
	
	def setClassDict(self, aClassInfo):
		self.setClassDictXmiId(aClassInfo)
		self.addClassInfoList(aClassInfo)
		
	# 이름으로 찾는 것은 의미가 없다. 왜냐면
	# 클래스의 이름은 같은 것이 있을수 있다.	
# 	def setClassDictByName(self, aClassInfo):
# 		self.classDictByName[aClassInfo.className]=aClassInfo		
# 	def getClassByName(self,className):
# 		return self.classDictByName[className]
		
	def setClassDictXmiId(self, aClassInfo):
		self.classDictXmiId[aClassInfo.xmiId]=aClassInfo
	def getClassByXmiId(self, xmiId):
		return self.classDictXmiId[xmiId]

	def addClassInfoList(self, aClassInfo):
		self.classInfoList.append(aClassInfo)
		
	def addClassAttributeList(self, aClassAttribute):
		self.classAttributeList.append(aClassAttribute)
	
	def getClassAttributeList(self):
		return self.classAttributeList
		
	def addClassOperation(self, aClassOperation):
		self.classOperationList.append(aClassOperation)
		
	def addDataType(self, aDataType):
		self.dataTypeList.append(aDataType)
		self.setDataTypeDict(aDataType)
		
	def setDataTypeDict(self, aDataType):
		self.dataTypeDict[aDataType.xmiId]=aDataType.name
		
	def getDataTypeByXmiId(self, xmiId):
		return self.dataTypeDict[xmiId]
	
	def getClassOperationList(self):
		return self.classOperationList		

	def addTaggedValueList(self, aTaggedValue):
		self.taggedValueList.append(aTaggedValue)
		self.setTaggedValueDictModelElementXmiId(aTaggedValue)
	def getTaggedValueList(self):
		return self.taggedValueList
		
	def setTaggedValueDictModelElementXmiId(self, aTaggedValue):
		self.taggedValueDictByModelElementXmiId[aTaggedValue.modelElement] = aTaggedValue
	def getTaggedValueDictModelElementXmiId(self, modelElementXmiId):
		try:
			out = self.taggedValueDictByModelElementXmiId[modelElementXmiId]
		except KeyError:
			out = None
		return out
	
	def makeRelationOfAttribute(self, aClassList):
		for attr in aClassList.getClassAttributeList():
			log.debug("---------------------------------------------------")
			self.makeRelationForClassAndAttribute(aClassList, attr)
			self.makeRelationForAttributeAndTaggedValue(aClassList, attr)
			self.setDataTypeOfAttr(aClassList, attr)
			#log.debug("attr.attributeName: ['%s']", attr.attributeName)

	def setDataTypeOfAttr(self, aClassList, attr):
		name = aClassList.getDataTypeByXmiId(attr.typeXmiId)
		attr.setAttrType(name)

	def makeRelationForClassAndAttribute(self, aClassList, attr):
		aClassInfo = aClassList.getClassByXmiId(attr.owner)
		aClassInfo.addClassAttributeList(attr)


	def makeRelationForAttributeAndTaggedValue(self, aClassList, attr):
		aTaggedValue = aClassList.getTaggedValueDictModelElementXmiId(attr.xmiId)
		if aTaggedValue:
			attr.setTaggedValue(aTaggedValue) # 속성 클래스과 TaggedValue의 릴레이션을 만든다.
			#log.debug("attr.xmiId: ['%s']",attr.xmiId)

	def makeRelationForClassAndOperation(self, aClassList):
		for oper in aClassList.getClassOperationList():
			log.debug("---------------------------------------------------")
			aClassInfo = aClassList.getClassByXmiId(oper.owner)
			aClassInfo.addClassOperation(oper)
			log.debug("aClassInfo.className: ['%s'], oper.name: ['%s']", aClassInfo.className, oper.name)


# if __name__ == "__main__":
# 	aClassList = ClassList()
# 	print aClassList.getJavaType('C')
