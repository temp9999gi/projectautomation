class MetaInfo:
	def __init__(self):
		pass
	def setXmiId(self, xmiId):
		self.xmiId = xmiId
	def getXmiId(self):
		return self.xmiId		
	def setOwner(self, owner):
		self.owner = owner
	def getOwner(self):
		return self.owner			
	def setVisibility(self, visibility):
		self.visibility = visibility
	def getVisibility(self):
		return self.visibility	
	def setName(self, name):
		self.name = name
	def getName(self):
		return self.name
		
