﻿# -*- coding: utf-8 -*-
# start
import sys
from XmiSaxHandler import *
from xml.sax import make_parser, handler
import logging
import utils
import xmiCommonUtil as xmiUtil
from ClassList import *
from Constants import *
from WriterExcel import *
# ToDo: xmi파싱 부분을 공통화해라..  
utils.initLog('ParseXmiMain.log')
utils.addConsoleLogging()
log = logging.getLogger('ParseXmiMain')

CONS = Constants()

class ParseXmiMain:  
	def getClassList(self):
		
		aClassList = ClassList()
		inFile  = CONS.INPUT_DIR / sys.argv[1]
		inFile = str(inFile)
		
		ClassList.XMI = xmiUtil.getXMI(inFile)
		
		h = XmiSaxHandler(aClassList)  
		parser = make_parser()  
		parser.setContentHandler(h)
		parser.parse(inFile)  
		
		aClassList.makeRelationOfAttribute(aClassList)
		aClassList.makeRelationForClassAndOperation(aClassList)
		return aClassList
		

class ExcelMain:
	def Run(self, aClassList):
		aWriterExcel = WriterExcel()
		aWriterExcel.writeExcel(aClassList)

if __name__ == '__main__':
# 	if len(sys.argv) < 2:
# 		print "USAGE: python ParseXmiMain.py input.xmi"
# 		sys.exit()
	aClassList = ParseXmiMain().getClassList()
	ExcelMain().Run(aClassList)
	
	print "(MSG) Ok"
