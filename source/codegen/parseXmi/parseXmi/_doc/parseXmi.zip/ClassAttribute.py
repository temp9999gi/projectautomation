﻿# -*- coding: utf-8 -*-
# start
from CommonUtil import *
from MetaInfo import *

class ClassAttribute(MetaInfo):
	def __init__(self):	
		MetaInfo.__init__	
	def setAttributeName(self, attributeName):
		self.attributeName = attributeName
		aCommonUtil = CommonUtil()
		self.upperNameIndex0 = aCommonUtil.getUpperNameIndex0(attributeName)		
	def getAttributeName(self):
		return self.attributeName
	
	def setTypeXmiId(self, typeXmiId):
		self.typeXmiId = typeXmiId
	def getTypeXmiId(self):
		return self.typeXmiId
	
	def setAttrType(self, attrType):
		self.attrType = attrType
	def getAttrType(self):
		return self.attrType
	
	def setTaggedValue(self, aTaggedValue):
		self.aTaggedValue = aTaggedValue
	def getTaggedValue(self):
		return self.aTaggedValue


