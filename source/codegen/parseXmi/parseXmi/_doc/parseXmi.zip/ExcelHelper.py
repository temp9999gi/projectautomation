﻿# -*- coding: utf-8 -*-
import sys
from win32com.client import Dispatch
import pythoncom
from CommonUtil import *
aCommonUtil = CommonUtil()


class ExcelHelper:
	def __init__(self):
		pass
	
	def openExcelSheet(self, filename):
		try:
			self.xl = Dispatch("Excel.Application")
			#filename은 풀 패스를 가지고 있어야 함
			self.xl.Workbooks.Open(filename)
			self.filename = filename

			self.workFile = self.xl.ActiveWorkbook.Name
		except pythoncom.com_error, (hr, msg, exc, arg):
			aCommonUtil.printPythonComError(hr, msg, exc, arg)

		
	def addSheet( self, aClassInfo ):
		try:
			xl, workFile = self.xl, self.workFile
			self.xl.Visible = False
			cnt = xl.Workbooks(workFile).Sheets.Count
			aSheet = xl.Workbooks(workFile).Sheets(cnt)
			xl.Workbooks(workFile).Sheets("templ").Copy( aSheet )
			
			aTargetSheet = xl.Workbooks(workFile).Sheets(cnt) # 복사된 시트
			#xl.Sheets(cnt).Name = aClassInfo.className
			xl.Sheets(cnt).Name = cnt
			self.writeClassInfo( aTargetSheet, aClassInfo )
			self.writeColumn( aTargetSheet, aClassInfo)
			
		except pythoncom.com_error, (hr, msg, exc, arg):
			aCommonUtil.printPythonComError(hr, msg, exc, arg)

	def deleteSheet( self, inSheetName ):
		try:
			xl = self.xl
			xl.DisplayAlerts = False
			self.xl.Visible = True
			cnt = xl.Workbooks(self.workFile).Sheets.Count
			#시트명으로 지울려니 잘 안되더라
			xl.Worksheets(cnt).Delete()
			xl.DisplayAlerts = True
			
		except pythoncom.com_error, (hr, msg, exc, arg):
			aCommonUtil.printPythonComError(hr, msg, exc, arg)

	def closeExcel(self):
		try:
			self.xl.ActiveWorkbook.Close(1) #1이면 저장을 한다.
			del self.xl
		except pythoncom.com_error, (hr, msg, exc, arg):
			aCommonUtil.printPythonComError(hr, msg, exc, arg)
			

class ExcelHelperClassDefiniton(ExcelHelper):
	def __init__(self):
		ExcelHelper.__init__
		
	def writeClassInfo( self, sh, aClassInfo ):
		# row, col
		sh.Cells(2, 3).Value = aClassInfo.subSystemName 	# 서브시스템명
		sh.Cells(2, 7).Value = aClassInfo.writer			# 작성자

		sh.Cells(3, 7).Value = aClassInfo.writeDate			# 작성일

		sh.Cells(3, 3).Value = aClassInfo.className			# 클래스명
		sh.Cells(4, 3).Value = 'description???'				# 클래스설명

	def writeColumn( self, sh, aClassInfo ):
		i = 6
		for attr in aClassInfo.attributeListOfClassInfo:
			sh.Cells(i, 1).Value = i - 5						# 번호
			sh.Cells(i, 2).Value = attr.attributeName			# 속성명
			sh.Cells(i, 4).Value = attr.visibility				# 가시성
			sh.Cells(i, 5).Value = attr.attrType				# 타입
			sh.Cells(i, 6).Value = 'default????'				# 기본값
			sh.Cells(i, 7).Value = 'desc?????'					# 설명
			i = i + 1
			
class ExcelHelperClassList(ExcelHelper):
	def __init__(self):
		ExcelHelper.__init__

	def writeClassInfo( self, sh, aClassInfo ):
		# row, col
		sh.Cells(2, 3).Value = aClassInfo.subSystemName 	# 업무명
		sh.Cells(2, 6).Value = aClassInfo.writer			# 작성자

	def writeColumn( self, sh, aClassInfo ):
		i = 4
		for attr in aClassInfo.attributeListOfClassInfo:
			sh.Cells(i, 1).Value = i - 5						# 번호
			sh.Cells(i, 2).Value = attr.attributeName			# 클래스명
			sh.Cells(i, 4).Value = attr.visibility				# 패키지명
			sh.Cells(i, 5).Value = attr.attrType				# 설명
			i = i + 1

