﻿# -*- coding: utf-8 -*-

from ClassInfo import *
from CommonUtil import *
from Constants import *
from ClassAttribute import *
from ClassOperation import *
from XmiDataType import *

from ClassList import *
from TaggedValue import *

import logging

log = logging.getLogger('xmiCommonUtil')

def getClass(attrs):
	aClassInfo = ClassInfo()
	log.debug("-aClassInfo--------------------------------------------------")
	# attrs : AttributesImpl instance
	for attrName in attrs.getNames():	# 속성 정보를 출력한다 (속성 이름, 속성 값)
		if attrName == 'name':
			aClassInfo.setClassName(attrs.getValue(attrName))
		if attrName == 'xmi.id':
			aClassInfo.setXmiId(attrs.getValue(attrName))
		if attrName == 'namespace':
			aClassInfo.setNamespace(attrs.getValue(attrName))
		log.debug("attrName: ['%s'], attrs.getValue(attrName): ['%s']",attrName, attrs.getValue(attrName))

	return aClassInfo

def getAttribute1(attrs):
	log.debug("-aClassAttribute--------------------------------------------------")
	aClassAttribute = ClassAttribute()
	for attrName in attrs.getNames():	# 속성 정보를 출력한다 (속성 이름, 속성 값)
		if attrName == 'name':
			attributeName=attrs.getValue(attrName)
			aClassAttribute.setAttributeName(attributeName)
		if attrName == 'type':
			aClassAttribute.setTypeXmiId(attrs.getValue(attrName))
		if attrName == 'visibility':
			aClassAttribute.setVisibility(attrs.getValue(attrName))
		if attrName == 'owner':
			aClassAttribute.setOwner(attrs.getValue(attrName))
		if attrName == 'xmi.id':
			aClassAttribute.setXmiId(attrs.getValue(attrName))

		log.debug("attrName: ['%s'], attrs.getValue(attrName): ['%s']",attrName, attrs.getValue(attrName))
	return aClassAttribute

def getOperation(attrs):
	aClassOperation = ClassOperation()
	log.debug("-aClassOperation--------------------------------------------------")
	for attrName in attrs.getNames():	# 속성 정보를 출력한다 (속성 이름, 속성 값)
		if attrName == 'name':
			aClassOperation.setName(attrs.getValue(attrName))
		if attrName == 'owner':
			aClassOperation.setOwner(attrs.getValue(attrName))
			
		log.debug("attrName: ['%s'], attrs.getValue(attrName): ['%s']",attrName, attrs.getValue(attrName))
	return aClassOperation

#<UML:DataType xmi.id="X.30" name="String" visibility="public" isSpecification="false" isRoot="false" isLeaf="false" isAbstract="false"/>
def getDataType(attrs):
	aXmiDataType = XmiDataType()
	log.debug("-aClassOperation--------------------------------------------------")
	for attrName in attrs.getNames():	# 속성 정보를 출력한다 (속성 이름, 속성 값)
		if attrName == 'xmi.id':
			aXmiDataType.setXmiId(attrs.getValue(attrName))
		if attrName == 'name':
			aXmiDataType.setName(attrs.getValue(attrName))
	return aXmiDataType

def isDocumentationOfTag(attrs):
	for attrName in attrs.getNames():
		if attrName == 'tag':
			if attrs.getValue(attrName) == 'documentation':
				return True
			else:
				return False

def getTaggedValue(attrs):
	aTaggedValue = TaggedValue()
	log.debug("-aTaggedValue--------------------------------------------------")
	for attrName in attrs.getNames():	# 속성 정보를 출력한다 (속성 이름, 속성 값)
		if attrName == 'xmi.id':
			aTaggedValue.setXmiId(attrs.getValue(attrName))
		if attrName == 'tag':
			aTaggedValue.setTag(attrs.getValue(attrName))
		if attrName == 'value':
			aTaggedValue.setValue(attrs.getValue(attrName))
		if attrName == 'modelElement':
			aTaggedValue.setModelElement(attrs.getValue(attrName))
		log.debug("attrName: ['%s'], attrs.getValue(attrName): ['%s']",attrName, attrs.getValue(attrName))
	return aTaggedValue

from xml.dom import minidom	
from XMI import *
def getXMI(xschemaFileName):

	if xschemaFileName:
		doc = minidom.parse(xschemaFileName)
	else:
		doc = minidom.parseString(xschema)
		
	xmi = doc.getElementsByTagName('XMI')[0]
	xmiver = str(xmi.getAttribute('xmi.version'))
	log.debug("XMI version: %s", xmiver)
	if xmiver >= "1.2":
		log.debug("Using xmi 1.2+ parser.")
		# XMI = XMI1_2()
	elif xmiver >= "1.1":
		log.debug("Using xmi 1.1+ parser.")
		XMI = XMI1_1()
	else:
		log.debug("Using xmi 1.1+ parser.")
		XMI = XMI1_0()
		
	return XMI	
