﻿# -*- coding: utf-8 -*-
# 
# generates xml files from Excel
# Programming by KyungUk, Sung
#
# Copyright (c) 2002 KyungUk, Sung
# start
import sys
from ClassList import *
#from ExcelReader import *
from Constants import *
#from CommonUtil import *
from ExcelHelper import *
from ReaderAppEnvXml import *

import shutil
class WriterExcel:
	def writeExcel(self, aClassList):
		CONS = Constants()
#		aCommonUtil = CommonUtil()
 		shutil.copyfile(CONS.INPUT_CLASS_EXCEL_TEMPLATE , CONS.OUTPUT_CLASS_EXCEL )
 		
		aExcelHelper = ExcelHelperClassDefiniton()
		aExcelHelper.openExcelSheet(CONS.OUTPUT_CLASS_EXCEL)

		for aClassInfo in aClassList.classInfoList:
			aReaderAppEnvXml = ReaderAppEnvXml()
			aReaderAppEnvXml.saveWriterInfo(aClassInfo, CONS.INPUT_APP_ENV_XML)
			aExcelHelper.addSheet( aClassInfo )
			
		aExcelHelper.deleteSheet('templ') #templ 시트 삭제

		aExcelHelper.closeExcel()

