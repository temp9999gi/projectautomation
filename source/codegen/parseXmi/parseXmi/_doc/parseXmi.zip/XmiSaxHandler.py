﻿# -*- coding: utf-8 -*-

from xml.sax import make_parser, handler
import xmiCommonUtil as xmiUtil
from Constants import *
from XMI import *

# log = logging.getLogger('XmiSaxHandler')
class XmiSaxHandler(handler.ContentHandler):
	def __init__(self, aClassList):
		self.setClassList(aClassList)
		self.XMI = aClassList.XMI

	def setClassList(self, aClassList):
		self.aClassList = aClassList
	def getClassList(self):
		return self.aClassList

	def startDocument(self):  # 문서의 시작에서 호출된다
		pass # print 'Start of Document'
	def endDocument(self):	# 문서의 끝에서 호출된다
		pass # print 'End of Document'
	def startElement(self, name, attrs): # 새로운 태그를 만날 때 호출된다
		
		# print 'Start Tag:', name
		if name == self.XMI.CLASS: #'UML:Class'
			self.aClassList.setClassDict(xmiUtil.getClass(attrs))
		if name == self.XMI.ATTRIBUTE: #'UML:Attribute'
			self.aClassList.addClassAttributeList(xmiUtil.getAttribute1(attrs))
		if name == self.XMI.OPERATION: #'UML:Operation'
			self.aClassList.addClassOperation(xmiUtil.getOperation(attrs))

		if name == self.XMI.DATATYPE: #'UML:DataType'
			self.aClassList.addDataType(xmiUtil.getDataType(attrs))

		if name == self.XMI.TAGGED_VALUE: # 'UML:TaggedValue'
			if xmiUtil.isDocumentationOfTag(attrs):
				self.aClassList.addTaggedValueList(xmiUtil.getTaggedValue(attrs))

	def endElement(self, name):   # 태그가 끝날 때 호출된다
		pass # print 'End Tag:', name
	def characters(self, content):  # 텍스트가 읽혀질 때 호출된다. 텍스트의 위치와 내용을 출력한다.
		pass
# 		print 'Location : (%s, %s)' % (self.locator.getLineNumber(), self.locator.getColumnNumber())
# 		print '\tText :', content.replace('\n', '\\n')
	def setDocumentLocator(self, locator):  # 전달되는 Locator 객체를 저장해둔다.
		self.locator = locator
