#! /usr/bin/env python
# -*- coding: utf-8 -*-
import string
#from airspeed import *
import airspeed
import xmlHelper

class Table :
    def __init__(self,tableEng):
        self.tableEng = tableEng
        self.tableKor = ''
        self.columnList = []

    def setTableKor(self,tableKor):
        self.tableKor = tableKor

    def addColumnList(self,aColumn):
        self.columnList.append(aColumn)
        aColumn.setTableEng(self.tableEng)
        #print '['+self.tableKor + ']' #, aColumn


class Column :
	def __init__(self,columnEng, propertyType):
		self.columnEng = columnEng
		self.propertyType = propertyType
		self.setUpperNameIndex0(columnEng)
	def setTableEng(self,tableEng):
		self.tableEng = tableEng
	def setPropertyType(self,propertyType):
		self.propertyType = propertyType
	def setUpperNameIndex0(self, attributeName):
		self.upperNameIndex0 = string.upper(attributeName[0]) + attributeName[1:]

def getTable():
	xmlFile = './input/Account.xml'

	c =  xmlHelper.getClassInfo(xmlFile, 'classInfo')
	aTable = Table(c.className)
	#print c.className

	for p in xmlHelper.getProperty(xmlFile, 'property'):
		(propertyName, propertyType) = (p.name ,p.type)
		aColumn = Column(propertyName, propertyType)
		aTable.addColumnList(aColumn)
	return aTable

#  <insert id="insertAccount" parameterClass="account">
#    insert into ACCOUNT (EMAIL, FIRSTNAME, LASTNAME, STATUS, ADDR1, ADDR2, CITY, STATE, ZIP, COUNTRY, PHONE, USERID)
#    values (#email#, #firstName#, #lastName#, #status#, #address1#,  #address2:VARCHAR#, #city#, #state#, #zip#,
#    #country#, #phone#, #username#)
#  </insert>

def getInsertSql(aTable):
    sql = "insert into ACCOUNT (EMAIL, FIRSTNAME, LASTNAME) values (#email#, #firstName#, #lastName#)"
    array2comma(aTable)
    return sql

def array2comma(aTable):
    s = ''
    for c in aTable.columnList:
        s = s + c.columnEng +' ,'

    out = s[0:len(s)-1]
    print out
    
    return out


def genMain():
	inTemplateFile = "./input/inputTmpl.java"
	template = airspeed.getTemplateFile(inTemplateFile)
	t = airspeed.Template(template)
	aTable = getTable()
	ret = t.merge({"aTable": aTable})

	#print ret
	print getInsertSql(aTable)

if __name__ in ('__main__','main'):
	genMain()


