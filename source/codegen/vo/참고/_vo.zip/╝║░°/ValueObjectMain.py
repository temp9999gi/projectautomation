#*- coding: utf-8 -*-   

#	private String   acctsCd ;  // ���������ڵ� 
#	private String   acctsNm ;  // ������ 

attribute_name = ['acctsCd', 'acctsNm', 'AcctsBalAmtDrCrFg']
searchListValue = {"class_name":"AcctsVO", "attribute_names":attribute_name}

from Cheetah.Template import Template
t = Template(file="ValueObject.tmpl", searchList=[searchListValue])

print t
