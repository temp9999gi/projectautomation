package com.ibatis.jpetstore.domain;

import java.io.Serializable;

public class Account implements Serializable {
  //[[[cog import dyno_cog; dyno_cog.writeProperty2('Account', cog.inFile) ]]]
  //[[[end]]]  

}